import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { ContractAbi, ContractAddress } from "../../utils/Contract";
import {
  prepareWriteContract,
  waitForTransaction,
  writeContract,
} from "@wagmi/core";
import { useAccount } from "wagmi";
import axios from "axios";
import toast from "react-hot-toast";
const ipfsClient = require("ipfs-http-client");
//const ipfs = ipfsClient.create({ host: 'ipfs.infura.io', port: 5001, protocol: 'https' });

const auth =
  "Basic " +
  Buffer.from(
    `2QHErwIJpoK3MpmsHbjR3gmFGZ8:68be7ad9dda60bf7fd303dbfb9c3dfbf`
  ).toString("base64");
const ipfs = ipfsClient.create({
  host: "ipfs.infura.io",
  port: 5001,
  protocol: "https",
  apiPath: "/api/v0",
  headers: { authorization: auth },
});

export default function AddProducts() {
  const [getValue, setgetValue] = useState([]);
  const [filesize_error, setfilesize_error] = useState("");
  const [imagesUpload, setimagesUpload] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const { address } = useAccount();
  const [spinner, setspinner] = useState(false);
  const inputRef = useRef();
  const navigate=useNavigate()

  const inputChange = (e) => {
    const { name, value } = e.target;
    setgetValue({ ...getValue, [name]: value });
  };

  const addProduct = async () => {
    try {
      setspinner(true);

      let jsonUsrl = "";
      if (imagesUpload !== "") {
        const fileAdded = await ipfs.add(imagesUpload);
        if (!fileAdded) {
          console.error("Something went wrong when updloading the file");
          setspinner(false);
          return;
        }
        const metadata = {
          title: "Asset Metadata",
          type: "object",
          properties: {
            image: fileAdded.path,
          },
        };
        const metadataAdded = await ipfs.add(JSON.stringify(metadata));
        if (!metadataAdded) {
          console.error("Something went wrong when updloading the file");
          setspinner(false);
          return;
        }
        let API_url = `https://skywalker.infura-ipfs.io/ipfs/${metadataAdded.path}`;
        let Response = await axios.get(API_url);
        jsonUsrl = `https://skywalker.infura-ipfs.io/ipfs/${Response.data.properties.image}`;
      }

      let constPriceValue = Number(getValue?.costPrice) * 1000000000000000000;
      let sellingPriceValue = Number(getValue?.sellingPrice) * 1000000000000000000;
      setspinner(true);
      const { request } = await prepareWriteContract({
        address: ContractAddress,
        abi: ContractAbi,
        functionName: "addMedicine",
        args: [
          getValue?.name,
          getValue?.quantity,
          constPriceValue,
          sellingPriceValue,
          getValue?.additionalNotes,
          jsonUsrl
        ],
        account: address,
      });
      const { hash } = await writeContract(request);
      const data = await waitForTransaction({
        hash,
      });
      setspinner(false);
      toast.success("Product add successfully");
      navigate('/')
    } catch (error) {
      console.log(error);
      setspinner(false);
    }
  };

  const handleClick = () => {
    // 👇️ open file input box on click of other element
    inputRef.current.click();
  };

  const imagepreview = (e) => {
    var file = e.target.files[0];
    const MAX_FILE_SIZE = 500; // 5MB
    const fileSizeKiloBytes = file.size / 1024;
    // console.log(fileSizeKiloBytes);
    if (fileSizeKiloBytes > MAX_FILE_SIZE) {
      setfilesize_error("File size is greater than maximum limit");
    } else {
      setImageUrl(URL.createObjectURL(e.target.files[0]));
      setimagesUpload(file);
    }
  };

  return (
    <div className=" mt-auto  w-full lg:p-10 p-4 bg-gray-50 ml-auto">
      <div className="mt-12">
        <div></div>
        <div className="flex flex-col-reverse lg:flex-row r justify-center ">
          <div className="lg:w-1/3 w-full  ">
            <div class="flex flex-col  mt-3">
              <div className="flex">
                <div className="">
                  <img
                    src={
                      imageUrl ||
                      "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1130&q=80"
                    }
                    alt=""
                    class="rounded w-2/3   object-scale-down"
                  />
                </div>
              </div>
              <div className="">
                <div className="py-3">
                  {/* <Link to="/login" class="w-full"> */}
                  <button
                    className={`w-2/3 border bg-primary hover:bg-indigo-700 transition-all text-white py-2 px-8 text-sm  cursor-pointer  rounded-lg`}
                    onClick={() => handleClick()}
                  >
                    <input
                      style={{ display: "none" }}
                      ref={inputRef}
                      type="file"
                      onChange={(e) => {
                        imagepreview(e);
                      }}
                    />
                    Browse Photos
                  </button>
                  {/* </Link> */}
                </div>
              </div>
              <div className="">
                <div className="">
                  {/* <Link to="/login" class="w-full"> */}
                  <button
                    className={`w-2/3 border bg-error text-white py-2 px-8 text-sm  cursor-pointer  rounded-lg`}
                    onClick={() => setImageUrl("")}
                  >
                    Remove Photo
                  </button>
                  {/* </Link> */}
                </div>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2 w-full lg:px-10">
            <>
              <div>
                <label htmlFor="name" className="text-sm font-medium">
                  Name
                </label>
                <input
                  // value={name}
                  name="name"
                  onChange={(e) => inputChange(e)}
                  type="text"
                  className={`w-full p-2 text-primary border rounded-md outline-none text-sm transition duration-150 ease-in-out mb-4`}
                  id="name"
                  placeholder="Remdesivir"
                />
              </div>
              <div>
                <label htmlFor="qty" className="text-sm font-medium">
                  Quantity in stock
                </label>
                <input
                  // value={quantity}
                  name="quantity"
                  onChange={(e) => inputChange(e)}
                  type="number"
                  className={`w-full p-2 text-primary border rounded-md outline-none text-sm transition duration-150 ease-in-out mb-4 `}
                  id="qty"
                  placeholder="220"
                />
              </div>
              {/* <div>
                <label htmlFor="lqty" className="text-sm font-medium">
                  Low stock warning
                </label>
                <input
                  // value={lowStock}
                  name="lowStock"
                  onChange={(e) => inputChange(e)}
                  type="number"
                  className={`w-full p-2 text-primary border rounded-md outline-none text-sm transition duration-150 ease-in-out mb-4`}
                  id="lqty"
                  placeholder="15"
                />
              </div> */}
              <div class="flex lg:flex-row flex-col justify-evenly w-full">
                <div>
                  <label htmlFor="cp" className="text-sm font-medium">
                    Cost Price (1 item)
                  </label>
                  <input
                    //   value={costPrice}
                    name="costPrice"
                    onChange={(e) => inputChange(e)}
                    type="number"
                    className={`w-3/7 p-2 text-primary border rounded-md outline-none text-sm transition duration-150 ease-in-out mb-4`}
                    id="cp"
                    placeholder="1 BNB"
                  />
                </div>
                <div>
                  <label htmlFor="sp" className="text-sm font-medium">
                    Selling Price (1 item)
                  </label>
                  <input
                    name="sellingPrice"
                    //   value={sellingPrice}
                    onChange={(e) => inputChange(e)}
                    type="number"
                    className={`w-3/7 p-2 text-primary border rounded-md outline-none text-sm transition duration-150 ease-in-out mb-4`}
                    id="sp"
                    placeholder="1 BNB"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="vendor" className="text-sm font-medium">
                  Additional Notes
                </label>
                <textarea
                  // value={additionalNotes}
                  onChange={(e) => inputChange(e)}
                  type="text"
                  name="additionalNotes"
                  rows="3"
                  className={`w-full p-2 text-primary form-textarea border rounded-md outline-none text-sm transition duration-150 ease-in-out mb-2`}
                  id="vendor"
                  placeholder="Enter some small description"
                />
              </div>
              <div class="flex flex-row justify-between mt-3">
                <div className="py-5">
                  <Link to="/" class="w-full">
                    <button
                      // onClick={this.clearForm}
                      className={`w-full cursor-pointer py-2 px-12 text-sm text-primary rounded-lg border border-primary focus:outline-none focus:`}
                    >
                      Cancel
                    </button>
                  </Link>
                </div>
                <div className="py-5">
                  <button
                    className={`w-full border bg-primary hover:bg-indigo-700 transition-all text-white py-2 px-10 text-sm  cursor-pointer  rounded-lg`}
                    onClick={addProduct}
                  >
                    {spinner ? "Loading..." : "Add Product"}
                  </button>
                </div>
                {/* {this.props.isLoading ? (
                <div className="py-5">
                  <button
                    className={`w-full border bg-primary hover:bg-indigo-700 transition-all text-white py-2 px-10 text-sm  cursor-pointer  rounded-lg`}
                  >
                    <Loader color="#fff" />
                  </button>
                </div>
              ) : (

              )} */}
              </div>
            </>
          </div>
        </div>
      </div>
    </div>
  );
}
