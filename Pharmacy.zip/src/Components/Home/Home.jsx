import React, { useEffect, useState } from "react";
import illustration from "../../Assets/homepage.png";
import heart from "../../Assets/heart.svg";
import rocket from "../../Assets/rocket.svg";
import CardVeiw from "../CradVeiw/CardVeiw";
import Web3 from "web3";
import SearchIcon from "../../Assets/search.svg";
import { ContractAbi, ContractAddress } from "../../utils/Contract";
import {
  prepareWriteContract,
  waitForTransaction,
  writeContract,
} from "@wagmi/core";
import toast from "react-hot-toast";

import { useAccount } from "wagmi";
export default function Home() {
  const webSupply = new Web3("wss://bsc-testnet-rpc.publicnode.com");
  const [userData, setuserData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredData, setFilteredData] = useState([]);
  const { address } = useAccount();
  const [spinner, setspinner] = useState(false);
  const [Idvalue, setIdvalue] = useState("");

  const getMedicine = async () => {
    try {
      let newArray = [];
      let ContractOf = new webSupply.eth.Contract(ContractAbi, ContractAddress);
      let medicineCount = await ContractOf.methods.medicineCount().call();
      for (let i = 1; i <= medicineCount; i++) {
        let medicines = await ContractOf.methods.medicines(i).call();
        newArray = [
          ...newArray,
          {
            id: i,
            name: medicines?.name,
            quantity: medicines?.quantity,
            buyingCost: Number(medicines.buyingCost) / 1000000000000000000,
            sellingCost: medicines?.sellingCost,
            detail: medicines.detail,
            image: medicines?.image,
          },
        ];
      }
      setuserData(newArray);
      setFilteredData(newArray);
      console.log("medicineCount", newArray);
    } catch (error) {
      console.log(error);
    }
  };
  const filterData = (query) => {
    const filteredArray = userData.filter((item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredData(filteredArray);
  };

  useEffect(() => {
    getMedicine();
  }, [searchQuery, spinner]);

  const buyProduct = async (id, quantity, price) => {
    try {
      setspinner(true);
      let constPriceValue = Number(price) * 1000000000000000000;
      setspinner(true);
      const { request } = await prepareWriteContract({
        address: ContractAddress,
        abi: ContractAbi,
        functionName: "buyMedicine",
        args: [id + 1, quantity.toString()],
        value: constPriceValue.toString(),
        account: address,
      });
      const { hash } = await writeContract(request);
      const data = await waitForTransaction({
        hash,
      });
      setTimeout(() => {
        setspinner(false);
        toast.success("You Buy this Product successfully");
      }, 3000);
    } catch (error) {
      console.log(error);
      setspinner(false);
    }
  };

  return (
    <div>
      <div className="h-screen max-w-screen">
        <div>
          <img
            class="absolute -ml-32 p-0 opacity-10 h-600 w-600 hidden lg:block flex z-0"
            alt="heart"
            src={heart}
          ></img>
        </div>
        <div className=" flex flex-col-reverse lg:flex-row">
          <div className="lg:w-3/5 w-screen  mb-auto">
            <div className="w-full bg-white mx-auto px-10  ml-6 py-5 md:px-10 xs:px-10 sm:px-10 lg:px-20">
              <h1 className="lg:text-5xl text-2xl font-bold antialiased  lg:mb-7 mb-2 mt-10">
                Store Medicine Record using Blockchain
              </h1>
              <h1 className="lg:text-3xl font-normal mb-6">
                A pharmacy management system built on blockchain technology
                offers a secure and transparent platform for tracking
                pharmaceutical supply chains, ensuring authenticity and
                preventing counterfeit drugs.
              </h1>
              {/* <div className="flex flex-wrap mt-3 z-40">

                <button className="bg-primary text-white cursor-pointer rounded-lg border py-3 px-8 focus:outline-none z-40">
                  <div class="flex flex-row justify-center ml-2 mr-2">
                    <div className="self-center text-sm">Get Started</div>
                    <div class="h-2 px-1">
                      <img
                        src={rocket}
                        alt="rocket"
                        className="object-scale-down z-0"
                      ></img>
                    </div>
                  </div>
                </button>

              </div> */}
            </div>
          </div>
          <div className="lg:w-2/5 w-screen z-0">
            <div class="items-center py-5 px-10 w-3/5 mx-auto w-full lg:w-full">
              <img src={illustration} alt="pharmacisct"></img>
            </div>
          </div>
        </div>

        <div className="px-10 md:px-10 sm:px-10 lg:px-20">
          <div>
            <h1 className="lg:text-3xl text-4xl font-extrabold text-center mb-6">
              Product List
            </h1>
          </div>

          <div className="flex space-x-1 items-stretch">
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              type="search"
              className={`w-full lg:p-4 p-2 text-primary border rounded-md outline-none text-sm transition duration-150 ease-in-out`}
              id="search"
              name="search_product"
              placeholder="Search for product"
            />
            <button
              type="search"
              onClick={filterData}
              className={`cursor-pointer bg-primary lg:p-8 p-2 text-sm text-white rounded-lg border focus:outline-none focus:`}
            >
              <img src={SearchIcon} alt="SearchIcon" />
              {/* <SearchIcon></SearchIcon> */}
            </button>
          </div>
          <div className="row">
            {filteredData?.map((items, index) => {
              return (
                <>
                  <div className="col-12 col-md-6 col-lg-3 mt-5" key={items}>
                    <CardVeiw
                      items={items}
                      handleClick={buyProduct}
                      index={index}
                      spinner={spinner}
                      setIdvalue={setIdvalue}
                      Idvalue={Idvalue}
                    />
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
