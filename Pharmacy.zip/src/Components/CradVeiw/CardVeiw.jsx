import React from "react";
import medicine from "../../Assets/medicine.jpg";

export default function CardVeiw({ items,handleClick,index,spinner,setIdvalue,Idvalue }) {


  return (
    <div className="mb-5">
      <div style={{height:"80vh"}} className="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
        <a href="#">
          <img className="rounded-t-lg" src={items?.image} alt="" style={{height:"30vh"}} />
        </a>
        <div className="p-3">
          <a href="#">
            <h5 className="mb-2 text-2xl font-bold tracking-tight text-gray-900">
              {items?.name}
            </h5>
          </a>
          <div className="flex justify-between">
            <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
              Price
            </p>
            <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
              {items?.buyingCost} BNB
            </p>
          </div>
          <div className="flex justify-between">
            <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
              Stock
            </p>
            <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
              {items?.quantity}
            </p>
          </div>
          <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
            {items?.detail}
          </p>

          <button   className={`w-full min-w-44 cursor-pointer bg-primary py-2 px-1 text-sm text-white rounded-lg border focus:outline-none focus:`}
          onClick={()=>(handleClick(index,items?.quantity,items?.buyingCost),setIdvalue(index+1))}
          >
            {
              spinner && Idvalue==index+1 ? "Loading...":"BUY NOW"
            }
             </button>

        </div>
      </div>
    </div>
  );
}
