import React from "react";
import logo from "../../Assets/fulllogo.png";
import { Link } from "react-router-dom";
import { useAccount, useNetwork, useSwitchNetwork } from "wagmi";
import { useWeb3Modal } from "@web3modal/wagmi/react";

export default function Header() {
  const { chain } = useNetwork();
  const { chains, switchNetwork } = useSwitchNetwork();
  const { address } = useAccount();
  const { open } = useWeb3Modal();
  return (
    <div>
      <div className="px-3">
        <nav class="navbar navbar-expand-lg navbar-light py-6">
          <div class="container-fluid">
            <div className="flex justify-between w-full">
              <Link to="/" class="w-full">
                <h4 className="font-extrabold sm:font-[16px] lg:text-[24px] logonavbar">
                  Pharmacy Management System{" "}
                </h4>
              </Link>
              <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarTogglerDemo02"
                aria-controls="navbarTogglerDemo02"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span class="navbar-toggler-icon"></span>
              </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <Link to="/addProduct" class="w-full">
                    <button
                      className={`w-full min-w-48 py-2 px-12 text-sm  cursor-pointer text-black rounded-lg`}

                    >
                      Add Product
                    </button>
                  </Link>
                </li>
                <li class="nav-item">
                  <button

                    className={`w-full min-w-44 cursor-pointer bg-primary py-2 px-1 text-sm text-white rounded-lg border focus:outline-none focus:`}
                    onClick={() =>
                      address
                        ? chain?.id == chains[0]?.id
                          ? open()
                          : switchNetwork?.(chains[0]?.id)
                        : open()
                    }
                  >
                    {address ? (
                      chain?.id == chains[0]?.id ||
                      chain?.id == chains[1]?.id ? (
                        address ? (
                          <>
                            {`${address?.substring(
                              0,
                              6
                            )}...${address?.substring(address.length - 4)}`}
                          </>
                        ) : (
                          <>Connect Wallet</>
                        )
                      ) : (
                        "Switch NetWork"
                      )
                    ) : (
                      <>Connect Wallet</>
                    )}
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}
