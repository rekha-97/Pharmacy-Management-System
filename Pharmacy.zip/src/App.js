import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header';
import { Route, Routes } from 'react-router-dom';
import AddProducts from './Components/AddProducts/AddProducts';
import Home from './Components/Home/Home';
import { Toaster } from 'react-hot-toast';

function App() {
  return (
    <div className="App">
      <Header />
      <Toaster />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/addProduct' element={<AddProducts />} />
      </Routes>
    </div>
  );
}

export default App;
